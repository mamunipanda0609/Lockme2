package com.company;

import com.company.screens.WelcomeScreen;

import java.io.PrintWriter;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        WelcomeScreen welcome = new WelcomeScreen();
        welcome.welcomeScreen();
        welcome.GetUserInput();
    }




}
